package com.fragmaData.service;

public interface DataReaderServiceInterface {
    
    public void readData();
    
    public void storeData(String[] data);

}
